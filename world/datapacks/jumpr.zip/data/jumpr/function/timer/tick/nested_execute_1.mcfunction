scoreboard players set $sec timer 59
execute if score $min timer matches ..-1 run function jumpr:timer/tick/nested_execute_0
