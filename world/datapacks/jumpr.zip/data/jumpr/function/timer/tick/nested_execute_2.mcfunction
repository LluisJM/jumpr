scoreboard players set $cs timer 99
scoreboard players remove $sec timer 1
execute if score $sec timer matches ..-1 run function jumpr:timer/tick/nested_execute_1
