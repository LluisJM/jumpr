scoreboard players set $min timer 0
function jumpr:timer/stop
