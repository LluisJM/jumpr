execute if score $running timer matches 1 run scoreboard players remove $cs timer 1
execute if score $cs timer matches ..-1 run function jumpr:timer/tick/nested_execute_2
