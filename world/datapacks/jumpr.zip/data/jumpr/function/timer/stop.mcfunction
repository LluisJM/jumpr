scoreboard players set $running timer 0
